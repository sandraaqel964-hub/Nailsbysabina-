# Nails by Sabina – säker bokning

## Start lokalt
1. Installera Node.js 20+.
2. Kopiera `.env.example` till `.env`.
3. Sätt ett långt, unikt `SESSION_SECRET` och ett adminlösenord på minst 12 tecken.
4. Kör `npm install`.
5. Kör `node setup-admin.js`.
6. Kör `npm start`.
7. Öppna `http://localhost:3000` och admin på `http://localhost:3000/admin`.

## Produktion
Använd HTTPS. Sätt `NODE_ENV=production`, ett starkt `SESSION_SECRET`, och förvara `.env` som hemlig serverkonfiguration. Databasfilen ska ligga på persistent disk. Byt adminlösenord omedelbart om det någonsin läcker.

Adminlösenordet lagras inte i klartext; det hashash med bcrypt. Adminsessionen är serverbaserad, cookie är HttpOnly/SameSite och Secure i produktion, login är rate-limitad och ändringar kräver CSRF-token.
