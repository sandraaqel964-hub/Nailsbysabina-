const path = require("path");
const crypto = require("crypto");
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === "production";

if (isProduction && !process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET saknas i produktion.");
}

const db = new Database(process.env.DB_PATH || path.join(__dirname, "data.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  service TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  design TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL
);
`);

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false });
const bookingLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false });

app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: __dirname }),
  secret: process.env.SESSION_SECRET || crypto.randomBytes(48).toString("hex"),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

function clean(value, max=500) {
  return String(value ?? "").trim().slice(0, max);
}
function validDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s); }
function validTime(s) { return /^(10:00|11:30|13:00|14:30|16:00|17:30|19:00)$/.test(s); }
function requireAdmin(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:"Inte inloggad"});
  next();
}
function csrf(req,res,next) {
  if (["GET","HEAD","OPTIONS"].includes(req.method)) return next();
  const token = req.get("X-CSRF-Token");
  if (!token || token !== req.session.csrfToken) return res.status(403).json({error:"Ogiltig säkerhetstoken"});
  next();
}

app.post("/api/login", authLimiter, (req,res,next) => {
  const username = clean(req.body.username, 80);
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
  const ok = user && bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({error:"Fel användarnamn eller lösenord"});
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.csrfToken = crypto.randomBytes(32).toString("hex");
    req.session.save(() => res.json({ok:true}));
  });
});

app.post("/api/logout", requireAdmin, csrf, (req,res,next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("connect.sid");
    res.json({ok:true});
  });
});

app.get("/api/session", (req,res) => {
  res.json({authenticated: !!req.session.userId, username: req.session.username || null, csrfToken: req.session.csrfToken || null});
});

app.post("/api/bookings", bookingLimiter, (req,res) => {
  const name=clean(req.body.name,100), phone=clean(req.body.phone,40), email=clean(req.body.email,120);
  const service=clean(req.body.service,100), date=clean(req.body.date,10), time=clean(req.body.time,5), design=clean(req.body.design,1000);
  if (!name || !phone || !service || !validDate(date) || !validTime(time)) return res.status(400).json({error:"Kontrollera dina uppgifter och välj en giltig tid."});
  const exists=db.prepare("SELECT id FROM bookings WHERE date=? AND time=? AND status!='cancelled'").get(date,time);
  if (exists) return res.status(409).json({error:"Den tiden är redan bokad."});
  const info=db.prepare("INSERT INTO bookings(name,phone,email,service,date,time,design,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)")
    .run(name,phone,email,service,date,time,design,"pending",new Date().toISOString());
  res.status(201).json({ok:true,id:info.lastInsertRowid});
});

app.get("/api/bookings", requireAdmin, (req,res) => {
  const rows=db.prepare("SELECT * FROM bookings ORDER BY date ASC,time ASC,created_at DESC").all();
  res.json(rows);
});

app.post("/api/bookings/:id/approve", requireAdmin, csrf, (req,res) => {
  const id=Number(req.params.id);
  const b=db.prepare("SELECT * FROM bookings WHERE id=?").get(id);
  if(!b) return res.status(404).json({error:"Bokningen finns inte"});
  const conflict=db.prepare("SELECT id FROM bookings WHERE date=? AND time=? AND id<>? AND status='approved'").get(b.date,b.time,id);
  if(conflict) return res.status(409).json({error:"Tiden är redan godkänd för en annan bokning."});
  db.prepare("UPDATE bookings SET status='approved' WHERE id=?").run(id);
  res.json({ok:true});
});

app.delete("/api/bookings/:id", requireAdmin, csrf, (req,res) => {
  db.prepare("DELETE FROM bookings WHERE id=?").run(Number(req.params.id));
  res.json({ok:true});
});

app.get("/admin", (req,res) => res.sendFile(path.join(__dirname,"public","admin.html")));
app.use(express.static(path.join(__dirname,"public")));

app.use((err,req,res,next) => {
  console.error(err);
  res.status(500).json({error:"Ett serverfel uppstod."});
});

app.listen(PORT, () => console.log(`Nails by Sabina kör på http://localhost:${PORT}`));
